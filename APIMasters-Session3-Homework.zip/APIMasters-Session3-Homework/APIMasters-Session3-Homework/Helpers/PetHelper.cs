﻿using APIMasters_Session3_Homework.DataModels;
using APIMasters_Session3_Homework.Resources;
using APIMasters_Session3_Homework.Tests.TestData;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace APIMasters_Session3_Homework.Helpers
{
    /// <summary>
    /// Demo class containing all methods for pets
    /// </summary>
    public class PetHelper
    {
        /// <summary>
        /// Send POST request to add new pet
        /// </summary>
        public static async Task<PetModel> AddNewPet(RestClient client)
        {
            var newPetData = GeneratePet.CreatePet();
            var postRequest = new RestRequest(Endpoints.PostPet());

            //Send Post Request to add new pet
            postRequest.AddJsonBody(newPetData);
            var postResponse = await client.ExecutePostAsync<PetModel>(postRequest);

            var createdPetData = newPetData;
            return createdPetData;
        }
    }
}
