﻿using APIMasters_Session3_Homework.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIMasters_Session3_Homework.Tests.TestData
{
    public class GeneratePet
    {
        public static PetModel CreatePet()
        {
            //Create Pet
            PetModel _PetModel = new PetModel();
            List<Category> category = new List<Category>();

            return new PetModel
            {
                Id = 1010101,
                Category = new Category { Id = 123, Name = "Dogs" },
                Name = "Bingo",
                PhotoUrls = new string[] { "https://sampleurl.com/" },
                Tags = new Category[] { new Category { Id = 1, Name = "dogsTags" } },
                Status = "available"
            };

        }
    }
}
