using APIMasters_Session3_Homework.DataModels;
using APIMasters_Session3_Homework.Helpers;
using APIMasters_Session3_Homework.Resources;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;


namespace APIMasters_Session3_Homework
{

    [TestClass]
    public class RestSharpTests : ApiBaseTest
    {
        private static List<PetModel> cleanUpList = new List<PetModel>();

        [TestInitialize]
        public async Task TestInitialize()
        {
            PetDetails = await PetHelper.AddNewPet(RestClient);
        }


        [TestMethod]
        public async Task PostMethod()
        {
            //Arrange
            var postRequest = new RestRequest(Endpoints.GetPetById(PetDetails.Id));
            cleanUpList.Add(PetDetails);

            //Act
            var postResponse = await RestClient.ExecuteGetAsync<PetModel>(postRequest);

            //Assert
            Assert.AreEqual(HttpStatusCode.OK, postResponse.StatusCode, "Status code is not equal to 200");
            Assert.AreEqual(PetDetails.Id, postResponse.Data.Id, "Id does not match.");
            Assert.AreEqual(PetDetails.Category.Id, postResponse.Data.Category.Id, "Category Id does not match.");
            Assert.AreEqual(PetDetails.Category.Name, postResponse.Data.Category.Name, "Category Name does not match.");
            Assert.AreEqual(PetDetails.Name, postResponse.Data.Name, "Name does not match.");
            Assert.AreEqual(PetDetails.PhotoUrls[0], postResponse.Data.PhotoUrls[0], "PhotoUrls does not match.");
            Assert.AreEqual(PetDetails.Tags[0].Id, postResponse.Data.Tags[0].Id, "Tags Id does not match.");
            Assert.AreEqual(PetDetails.Tags[0].Name, postResponse.Data.Tags[0].Name, "Tags Name does not match.");
            Assert.AreEqual(PetDetails.Status, postResponse.Data.Status, "Status does not match.");


        }


        [TestCleanup]
        public async Task TestCleanup()
        {
            foreach (var data in cleanUpList)
            {
                var restRequest = new RestRequest(Endpoints.GetPetById(data.Id));
                var restResponse = await RestClient.DeleteAsync(restRequest);
            }
        }

    }
}