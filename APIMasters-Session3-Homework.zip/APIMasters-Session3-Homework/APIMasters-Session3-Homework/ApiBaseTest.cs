﻿using APIMasters_Session3_Homework.DataModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIMasters_Session3_Homework
{
    public class ApiBaseTest
    {
        public RestClient RestClient { get; set; }
        public PetModel PetDetails { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            RestClient = new RestClient();
        }

        [TestCleanup]
        public void CleanUp()
        {

        }


    }
}
