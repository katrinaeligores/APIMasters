using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;


[assembly: Parallelize(Workers = 10, Scope = ExecutionScope.MethodLevel)]
namespace APIMasters_Session2_Part2_Homework
{
    [TestClass]
    public class RestSharpTests
    {
        private static RestClient restClient;

        private static readonly string BaseURL = "https://petstore.swagger.io/v2/";

        private static readonly string PetEndpoint = "pet";

        private static string GetURL(string enpoint) => $"{BaseURL}{enpoint}";

        private static Uri GetURI(string endpoint) => new Uri(GetURL(endpoint));

        private readonly List<PetModel> cleanUpList = new List<PetModel>();


        [TestInitialize]
        public async Task TestInitialize()
        {
            restClient = new RestClient();
        }


        [TestCleanup]
        public async Task TestCleanup()
        {
            foreach (var data in cleanUpList)
            {
                var restRequest = new RestRequest(GetURI($"{PetEndpoint}/{data.Id}"));
                var restResponse = await restClient.DeleteAsync(restRequest);
            }
        }


        [TestMethod]
        public async Task PostMethod()
        {
            #region CreateUser

            PetModel _PetModel = new PetModel();
            List<Category> category = new List<Category>();

            // Create Json Object
            _PetModel = new PetModel()
            {
                Id = 1010101,
                Category = new Category { Id = 123, Name = "Dogs" },
                Name = "Bingo",
                PhotoUrls = new string[] { "https://sampleurl.com/" },
                Tags = new Category[] { new Category { Id = 1, Name = "dogsTags" } },
                Status = "available"
            };

            // Send Post Request
            var temp = GetURI(PetEndpoint);
            var postRestRequest = new RestRequest(GetURI(PetEndpoint)).AddJsonBody(_PetModel);
            var postRestResponse = await restClient.ExecutePostAsync(postRestRequest);
            #endregion

            #region GetUser
            var restRequest = new RestRequest(GetURI($"{PetEndpoint}/{_PetModel.Id}"), Method.Get);
            var restResponse = await restClient.ExecuteAsync<PetModel>(restRequest);
            #endregion

            #region Assertions
            Assert.AreEqual(HttpStatusCode.OK, restResponse.StatusCode, "Status code is not equal to 200");
            Assert.AreEqual(_PetModel.Id, restResponse.Data.Id, "Id does not match.");
            Assert.AreEqual(_PetModel.Category.Id, restResponse.Data.Category.Id, "Category Id does not match.");
            Assert.AreEqual(_PetModel.Category.Name, restResponse.Data.Category.Name, "Category Name does not match.");
            Assert.AreEqual(_PetModel.Name, restResponse.Data.Name, "Name does not match.");
            Assert.AreEqual(_PetModel.PhotoUrls[0], restResponse.Data.PhotoUrls[0], "PhotoUrls does not match.");
            Assert.AreEqual(_PetModel.Tags[0].Id, restResponse.Data.Tags[0].Id, "Tags Id does not match.");
            Assert.AreEqual(_PetModel.Tags[0].Name, restResponse.Data.Tags[0].Name, "Tags Name does not match.");
            Assert.AreEqual(_PetModel.Status, restResponse.Data.Status, "Status does not match.");
            #endregion

            #region CleanUp
            cleanUpList.Add(_PetModel);
            #endregion
        }
    }
}
