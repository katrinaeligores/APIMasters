﻿using FinalProjectHTTP.DataModels;
using FinalProjectHTTP.Helpers;
using FinalProjectHTTP.TestData;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

[assembly: Parallelize(Workers = 10, Scope = ExecutionScope.MethodLevel)]
namespace FinalProjectHTTP
{
    [TestClass]
    public class BookingTests
    {
        private BookingHelpers bookingHelpers;

        [TestMethod]
        public async Task CreateBooking()
        {
            bookingHelpers = new BookingHelpers();

            var createBooking = await bookingHelpers.AddNewBooking();
            var getResponse = JsonConvert.DeserializeObject<BookingJson>(createBooking.Content.ReadAsStringAsync().Result);

            Assert.AreEqual(createBooking.StatusCode, HttpStatusCode.OK);

            var getCreatedBooking = await bookingHelpers.GetBookingById(getResponse.BookingId);
            var getCreatedBookingResponse = JsonConvert.DeserializeObject<BookingModel>(getCreatedBooking.Content.ReadAsStringAsync().Result);

            var expectedBookingData = GenerateBooking.bookingDetails();
            Assert.AreEqual(expectedBookingData.Firstname, getCreatedBookingResponse.Firstname, "Firstname does not match.");
            Assert.AreEqual(expectedBookingData.Lastname, getCreatedBookingResponse.Lastname, "Lastname does not match.");
            Assert.AreEqual(expectedBookingData.Totalprice, getCreatedBookingResponse.Totalprice, "Total price does not match.");
            Assert.AreEqual(expectedBookingData.Depositpaid, getCreatedBookingResponse.Depositpaid, "Deposit paid does not match.");
            Assert.AreEqual(expectedBookingData.Bookingdates.Checkin, getCreatedBookingResponse.Bookingdates.Checkin, "Checkin does not match.");
            Assert.AreEqual(expectedBookingData.Bookingdates.Checkout, getCreatedBookingResponse.Bookingdates.Checkout, "Checkout does not match.");
            Assert.AreEqual(expectedBookingData.Additionalneeds, getCreatedBookingResponse.Additionalneeds, "Additional needs does not match.");

            await bookingHelpers.DeleteBookingById(getResponse.BookingId);
        }

        [TestMethod]
        public async Task UpdateFirstAndLastNameOfBooking()
        {
            bookingHelpers = new BookingHelpers();

            var createBooking = await bookingHelpers.AddNewBooking();
            var getResponse = JsonConvert.DeserializeObject<BookingJson>(createBooking.Content.ReadAsStringAsync().Result);

            Assert.AreEqual(createBooking.StatusCode, HttpStatusCode.OK);

            var getCreatedBooking = await bookingHelpers.GetBookingById(getResponse.BookingId);
            var getCreatedBookingResponse = JsonConvert.DeserializeObject<BookingModel>(getCreatedBooking.Content.ReadAsStringAsync().Result);

            var updatedBookingDetails = new BookingModel()
            {
                Firstname = "Anna",
                Lastname = "Banana",
                Totalprice = getCreatedBookingResponse.Totalprice,
                Depositpaid = getCreatedBookingResponse.Depositpaid,
                Bookingdates = getCreatedBookingResponse.Bookingdates,
                Additionalneeds = getCreatedBookingResponse.Additionalneeds
            };

            var updateBooking = await bookingHelpers.UpdateBookingById(updatedBookingDetails, getResponse.BookingId);
            var getUpdateBookingResponse = JsonConvert.DeserializeObject<BookingJson>(updateBooking.Content.ReadAsStringAsync().Result);

            Assert.AreEqual(updateBooking.StatusCode, HttpStatusCode.OK);

            var getUpdatedBooking = await bookingHelpers.GetBookingById(getResponse.BookingId);
            var getUpdatedBookingResponse = JsonConvert.DeserializeObject<BookingModel>(getUpdatedBooking.Content.ReadAsStringAsync().Result);

            Assert.AreEqual(updatedBookingDetails.Firstname, getUpdatedBookingResponse.Firstname, "Firstname does not match.");
            Assert.AreEqual(updatedBookingDetails.Lastname, getUpdatedBookingResponse.Lastname, "Lastname does not match.");
            Assert.AreEqual(updatedBookingDetails.Totalprice, getUpdatedBookingResponse.Totalprice, "Total price does not match.");
            Assert.AreEqual(updatedBookingDetails.Depositpaid, getUpdatedBookingResponse.Depositpaid, "Deposit paid does not match.");
            Assert.AreEqual(updatedBookingDetails.Bookingdates.Checkin, getUpdatedBookingResponse.Bookingdates.Checkin, "Checkin does not match.");
            Assert.AreEqual(updatedBookingDetails.Bookingdates.Checkout, getUpdatedBookingResponse.Bookingdates.Checkout, "Checkout does not match.");
            Assert.AreEqual(updatedBookingDetails.Additionalneeds, getUpdatedBookingResponse.Additionalneeds, "Additional needs does not match.");

            await bookingHelpers.DeleteBookingById(getResponse.BookingId);
        }

        [TestMethod]
        public async Task DeleteCreatedBooking()
        {
            bookingHelpers = new BookingHelpers();

            var createBooking = await bookingHelpers.AddNewBooking();
            var getResponse = JsonConvert.DeserializeObject<BookingJson>(createBooking.Content.ReadAsStringAsync().Result);

            Assert.AreEqual(createBooking.StatusCode, HttpStatusCode.OK);

            var deleteBooking = await bookingHelpers.DeleteBookingById(getResponse.BookingId);

            Assert.AreEqual(deleteBooking.StatusCode, HttpStatusCode.Created);
        }

        [TestMethod]
        public async Task GetInvalidBookingId()
        {
            bookingHelpers = new BookingHelpers();
            int invalidBookingId = 999999;

            var getCreatedBooking = await bookingHelpers.GetBookingById(invalidBookingId);

            Assert.AreEqual(getCreatedBooking.StatusCode, HttpStatusCode.NotFound);
        }
    }
}
