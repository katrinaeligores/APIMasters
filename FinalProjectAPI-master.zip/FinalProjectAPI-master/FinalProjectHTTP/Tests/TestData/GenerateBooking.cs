﻿using FinalProjectHTTP.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectHTTP.TestData
{
    public class GenerateBooking
    {
        public static BookingModel bookingDetails()
        {
            DateTime dateTime = DateTime.UtcNow.Date;

            return new BookingModel
            {
                Firstname = "Bennie",
                Lastname = "Binene",
                Totalprice = 101,
                Depositpaid = true,
                Bookingdates = new Bookingdates()
                {
                    Checkin = dateTime,
                    Checkout = dateTime.AddDays(1)
                },
                Additionalneeds = "Toiletries"
            };
        }
    }
}
