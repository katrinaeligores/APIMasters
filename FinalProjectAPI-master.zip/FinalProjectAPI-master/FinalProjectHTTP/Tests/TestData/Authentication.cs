﻿using FinalProjectHTTP.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectHTTP.TestData
{
    public class Authentication
    {
        public static UserTokenJson userToken()
        {
            return new UserTokenJson
            {
                Username = "admin",
                Password = "password123"
            };
        }
    }
}
