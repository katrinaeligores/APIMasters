﻿using FinalProjectREST.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectREST.Tests.TestData
{
    public class GenerateBooking
    {
        public static GetBookingJson bookingDetails()
        {
            DateTime dateTime = DateTime.UtcNow.Date;

            return new GetBookingJson
            {
                Firstname = "Russel",
                Lastname = "Rusty",
                Totalprice = 102,
                Depositpaid = true,
                Bookingdates = new Bookingdates()
                {
                    Checkin = dateTime,
                    Checkout = dateTime.AddDays(1)
                },
                Additionalneeds = "Extra beddings"
            };
        }
    }
}
