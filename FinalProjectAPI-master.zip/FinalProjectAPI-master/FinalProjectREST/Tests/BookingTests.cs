﻿using FinalProjectREST.DataModels;
using FinalProjectREST.Helpers;
using FinalProjectREST.Tests.TestData;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

[assembly: Parallelize(Workers = 10, Scope = ExecutionScope.MethodLevel)]
namespace FinalProjectREST.Tests
{
    [TestClass]
    public class BookingTests : BookingTestsBase
    {

        [TestInitialize]
        public async Task TestInitialize()
        {
            var restResponse = await BookingHelper.AddNewBooking(RestClient);
            BookingDetails = restResponse.Data;

            Assert.AreEqual(restResponse.StatusCode, HttpStatusCode.OK);
        }

        [TestMethod]
        public async Task CreateBooking()
        {
            var getCreatedBooking = await BookingHelper.GetBookingById(RestClient, BookingDetails.BookingId);

            var expectedBookingData = GenerateBooking.bookingDetails();
            Assert.AreEqual(expectedBookingData.Firstname, getCreatedBooking.Data.Firstname);
            Assert.AreEqual(expectedBookingData.Lastname, getCreatedBooking.Data.Lastname);
            Assert.AreEqual(expectedBookingData.Totalprice, getCreatedBooking.Data.Totalprice);
            Assert.AreEqual(expectedBookingData.Depositpaid, getCreatedBooking.Data.Depositpaid);
            Assert.AreEqual(expectedBookingData.Bookingdates.Checkin, getCreatedBooking.Data.Bookingdates.Checkin);
            Assert.AreEqual(expectedBookingData.Bookingdates.Checkout, getCreatedBooking.Data.Bookingdates.Checkout);
            Assert.AreEqual(expectedBookingData.Additionalneeds, getCreatedBooking.Data.Additionalneeds);

            await BookingHelper.DeleteBookingById(RestClient, BookingDetails.BookingId);
        }

        [TestMethod]
        public async Task UpdateFirstAndLastNameOfBooking()
        {
            var getCreatedBooking = await BookingHelper.GetBookingById(RestClient, BookingDetails.BookingId);

            var updatedBookingDetails = new GetBookingJson()
            {
                Firstname = "Patty",
                Lastname = "Patutchi",
                Totalprice = getCreatedBooking.Data.Totalprice,
                Depositpaid = getCreatedBooking.Data.Depositpaid,
                Bookingdates = getCreatedBooking.Data.Bookingdates,
                Additionalneeds = getCreatedBooking.Data.Additionalneeds
            };

            var updateBooking = await BookingHelper.UpdateBookingById(RestClient, updatedBookingDetails, BookingDetails.BookingId);

            Assert.AreEqual(updateBooking.StatusCode, HttpStatusCode.OK);

            var getUpdatedBooking = await BookingHelper.GetBookingById(RestClient, BookingDetails.BookingId);

            Assert.AreEqual(updatedBookingDetails.Firstname, getUpdatedBooking.Data.Firstname);
            Assert.AreEqual(updatedBookingDetails.Lastname, getUpdatedBooking.Data.Lastname);
            Assert.AreEqual(updatedBookingDetails.Totalprice, getUpdatedBooking.Data.Totalprice);
            Assert.AreEqual(updatedBookingDetails.Depositpaid, getUpdatedBooking.Data.Depositpaid);
            Assert.AreEqual(updatedBookingDetails.Bookingdates.Checkin, getUpdatedBooking.Data.Bookingdates.Checkin);
            Assert.AreEqual(updatedBookingDetails.Bookingdates.Checkout, getUpdatedBooking.Data.Bookingdates.Checkout);
            Assert.AreEqual(updatedBookingDetails.Additionalneeds, getUpdatedBooking.Data.Additionalneeds);

            await BookingHelper.DeleteBookingById(RestClient, BookingDetails.BookingId);
        }

        [TestMethod]
        public async Task DeleteCreatedBooking()
        {
            var deleteBooking = await BookingHelper.DeleteBookingById(RestClient, BookingDetails.BookingId);

            Assert.AreEqual(deleteBooking.StatusCode, HttpStatusCode.Created);
        }

        [TestMethod]
        public async Task GetInvalidBookingId()
        {
            int invalidBookingId = 999999;

            var getCreatedBooking = await BookingHelper.GetBookingById(RestClient, invalidBookingId);

            Assert.AreEqual(getCreatedBooking.StatusCode, HttpStatusCode.NotFound);

            await BookingHelper.DeleteBookingById(RestClient, BookingDetails.BookingId);
        }
    }
}
