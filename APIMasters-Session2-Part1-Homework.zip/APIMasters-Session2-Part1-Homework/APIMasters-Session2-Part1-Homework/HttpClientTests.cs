using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[assembly: Parallelize(Workers = 10, Scope = ExecutionScope.MethodLevel)]

namespace APIMasters_Session2_Part1_Homework
{
    [TestClass]
    public class HttpClientTests
    {

        private static HttpClient httpClient;

        private static readonly string BaseURL = "https://petstore.swagger.io/v2/";

        private static readonly string PetEndpoint = "pet";

        private static string GetURL(string enpoint) => $"{BaseURL}{enpoint}";

        private static Uri GetURI(string endpoint) => new Uri(GetURL(endpoint));

        private readonly List<PetModel> cleanUpList = new List<PetModel>();


        [TestInitialize]
        public void TestInitialize()
        {
            httpClient = new HttpClient();
        }


        [TestCleanup]
        public async Task TestCleanUp()
        {
            foreach (var data in cleanUpList)
            {
                var httpResponse = await httpClient.DeleteAsync(GetURL($"{PetEndpoint}/{data.Id}"));
            }
        }


        [TestMethod]
        public async Task PutMethod()
        {
            #region create data

            PetModel _PetModel = new PetModel();
            List<Category> category = new List<Category>();


            // Create Json Object

            _PetModel = new PetModel()
            {
                Id = 1010101,
                Category = new Category { Id = 123, Name = "Dogs" },
                Name = "Bingo",
                PhotoUrls = new string[] { "https://sampleurl.com/" },
                Tags = new Category[] { new Category { Id = 1, Name = "dogsTags" } },
                Status = "available"
            };


            // Serialize Content
            var request = JsonConvert.SerializeObject(_PetModel);
            var postRequest = new StringContent(request, Encoding.UTF8, "application/json");

            // Send Post Request
            await httpClient.PostAsync(GetURL(PetEndpoint), postRequest);

            #endregion

            #region get Username of the created data

            // Get Request
            var getResponse = await httpClient.GetAsync(GetURI($"{PetEndpoint}/{_PetModel.Id}"));

            // Deserialize Content
            var listPetData = JsonConvert.DeserializeObject<PetModel>(getResponse.Content.ReadAsStringAsync().Result);

            // filter created data
            var createdUserData = listPetData.Id;

            #endregion

            #region send put request to update data

            // Update value of userData
            _PetModel = new PetModel()
            {
                Id = 1010101,
                Category = new Category { Id = 456, Name = "Cats" },
                Name = "Meowie",
                PhotoUrls = new string[] { "https://sampleurl.com/" },
                Tags = new Category[] { new Category { Id = 2, Name = "catsTags" } },
                Status = "sold"
            };

            // Serialize Content
            request = JsonConvert.SerializeObject(_PetModel);
            postRequest = new StringContent(request, Encoding.UTF8, "application/json");

            // Send Put Request
            var httpResponse = await httpClient.PutAsync(GetURL($"{PetEndpoint}"), postRequest);

            // Get Status Code
            var statusCode = httpResponse.StatusCode;

            #endregion

            #region get updated data

            // Get Request
            getResponse = await httpClient.GetAsync(GetURI($"{PetEndpoint}/{_PetModel.Id}"));

            // Deserialize Content
            listPetData = JsonConvert.DeserializeObject<PetModel>(getResponse.Content.ReadAsStringAsync().Result);

            // filter created data
            createdUserData = listPetData.Id;

            #endregion

            #region cleanup data

            // Add data to cleanup list
            cleanUpList.Add(listPetData);

            #endregion

            #region assertion

            // Assertion
            Assert.AreEqual(HttpStatusCode.OK, statusCode, "Status code is not equal to 201");
            Assert.AreEqual(_PetModel.Id, listPetData.Id, "Id does not match");
            Assert.AreEqual(_PetModel.Category.Id, listPetData.Category.Id, "Category Id does not match");
            Assert.AreEqual(_PetModel.Category.Name, listPetData.Category.Name, "Category Name does not match");
            Assert.AreEqual(_PetModel.Name, listPetData.Name, "Name not matching");
            Assert.AreEqual(_PetModel.PhotoUrls[0], listPetData.PhotoUrls[0], "PhotoUrls does not match");
            Assert.AreEqual(_PetModel.Tags[0].Id, listPetData.Tags[0].Id, "Tags Id does not match");
            Assert.AreEqual(_PetModel.Tags[0].Name, listPetData.Tags[0].Name, "Tags Name does not match");
            Assert.AreEqual(_PetModel.Status, listPetData.Status, "Status does not match");

            #endregion
        }
    }
}