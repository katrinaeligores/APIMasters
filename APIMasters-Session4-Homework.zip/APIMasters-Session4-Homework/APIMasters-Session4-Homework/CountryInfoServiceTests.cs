using Microsoft.VisualStudio.TestTools.UnitTesting;
using CountryInfoService;

[assembly: Parallelize(Workers = 10, Scope = ExecutionScope.MethodLevel)]
namespace SoapAPI
{
    [TestClass]
    public class CountryInfoTestScenarios
    {
        private readonly CountryInfoServiceSoapTypeClient countryInfo
           = new CountryInfoServiceSoapTypeClient(CountryInfoServiceSoapTypeClient.EndpointConfiguration.CountryInfoServiceSoap);

        [TestMethod]
        public void ValidateListOfCountryNamesByCodeIsByAscendingOrder()
        {
            var listOfCountryNamesByCode = countryInfo.ListOfCountryNamesByCode();
            var isOrderedByAscending = listOfCountryNamesByCode.SequenceEqual(listOfCountryNamesByCode.OrderBy(a => a.sISOCode));
            Assert.IsTrue(isOrderedByAscending);
        }

        [TestMethod]
        public void ValidateInvalidCountryCode()
        {
            var invalidCountryCode = "ABC";
            var responseMessage = countryInfo.CountryName(invalidCountryCode);
            Assert.IsTrue(responseMessage.Contains("Country not found in the database"), $"Country code {invalidCountryCode} can be found in the database.");
        }

        [TestMethod]
        public void ValidateLastCountryByCodeMatchesCorrectCountryName()
        {
            var lastCountryCodeFromList = countryInfo.ListOfCountryNamesByCode().Last();
            var countryName = countryInfo.CountryName(lastCountryCodeFromList.sISOCode);

            Assert.AreEqual(lastCountryCodeFromList.sName, countryName);
        }
    }
}